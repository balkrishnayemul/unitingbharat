package com.blondera.unitingbharat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.blondera.unitingbharat.utils.ConfirmDialog;
import com.blondera.unitingbharat.utils.ProjectApi;

import org.json.JSONArray;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {

    EditText edt_fnm,edt_lnm,edt_add,edt_add1,edt_land,edt_dist,edt_st,edt_pin,edt_mob,edt_pan,edt_upi,edt_ref,edt_pass;
    ProgressBar pb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        getSupportActionBar().hide();
        Intent mainIntent = getIntent();
        String prefix="";
        if (mainIntent!=null && mainIntent.getData()!=null
                && (mainIntent.getData().getScheme().equals("https"))){
            Uri data = mainIntent.getData();
            prefix = data.getQueryParameter("ref");
            List<String> pathSegments = data.getPathSegments();
            //if(pathSegments.size()>0)
               // prefix=pathSegments.get(0); // This will give you prefix as path
        }

        edt_fnm = findViewById(R.id.edt_name);
        edt_lnm = findViewById(R.id.edt_lname);
        edt_add = findViewById(R.id.edt_address);
        edt_add1 = findViewById(R.id.edt_address1);
        edt_land = findViewById(R.id.edt_landmark);
        edt_dist = findViewById(R.id.edt_dst);
        edt_st = findViewById(R.id.edt_st);
        edt_pin = findViewById(R.id.edt_pin);
        edt_mob = findViewById(R.id.edt_mob);
        edt_pan = findViewById(R.id.edt_pan);
        edt_upi = findViewById(R.id.edt_upi);
        edt_ref = findViewById(R.id.edt_ref);
        edt_pass = findViewById(R.id.edt_pass);
        pb = findViewById(R.id.pb);
        edt_ref.setText(prefix);
    }

    public void login(View view) {
        Intent loginIntent = new Intent(getApplicationContext(),LoginActivity.class);
        finish();
        startActivity(loginIntent);
    }

    public void register(View view) {
        ConfirmDialog dialog = new ConfirmDialog();
        dialog.show(getSupportFragmentManager(),"Warning");
    }

    public void signUp(){
        pb.setVisibility(View.VISIBLE);
        RequestQueue que = Volley.newRequestQueue(getApplicationContext());
        StringRequest req = new StringRequest(Request.Method.POST, ProjectApi.register, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                pb.setVisibility(View.VISIBLE);
                try {
                    JSONArray arr = new JSONArray(response);
                    String msg = arr.getJSONObject(0).getString("msg");
                    Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_LONG).show();
                    if (msg.equalsIgnoreCase("success")){
                        Intent home = new Intent(getApplicationContext(), LoginActivity.class);
                        finish();
                        startActivity(home);
                    }
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                pb.setVisibility(View.VISIBLE);
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> param = new HashMap<String,String>();
                //upino="+edtupi.getText().toString()+"&adhar="+edtadhar.getText().toString()+"&name="+edtname.getText().toString()+
                // "&mobile="+edtmob.getText().toString()+"&ref="+edtref.getText().toString()+"&password="+edtpassword.getText().toString()
                param.put("upino",edt_upi.getText().toString());
                param.put("name",edt_fnm.getText().toString()+" "+edt_lnm.getText().toString());
                param.put("mobile",edt_mob.getText().toString());
                param.put("ref",edt_ref.getText().toString());
                param.put("ct",edt_dist.getText().toString());
                param.put("st",edt_st.getText().toString());
                param.put("land",edt_land.getText().toString());
                param.put("add",edt_add.getText().toString()+ " "+edt_add1.getText().toString());
                param.put("pin",edt_pin.getText().toString());
                param.put("pan",edt_pan.getText().toString());
                param.put("password",edt_pass.getText().toString());

                return param;
            }
        };
        que.add(req);
    }
}