package com.blondera.unitingbharat.utils;

import java.util.ArrayList;

public class AdData {
    String path;

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public static ArrayList<AdData> adData = new ArrayList<AdData>();
}
