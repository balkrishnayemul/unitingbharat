package com.blondera.unitingbharat.utils;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.blondera.unitingbharat.R;
import com.blondera.unitingbharat.RegisterActivity;

public class ConfirmDialog extends DialogFragment {
    CheckBox chk_t,chk_a;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.dialog_confirm,container,false);
        Button btn_ack = view.findViewById(R.id.btn_ack);
        chk_t = view.findViewById(R.id.chk_terms);
        chk_a = view.findViewById(R.id.chk_ack);
        btn_ack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (chk_a.isChecked() && chk_t.isChecked()) {
                    ((RegisterActivity) getActivity()).signUp();
                    dismiss();
                }
                else{
                    Toast.makeText(getActivity().getApplicationContext(),"Please Accept Terms & conditions and Acknolodgement",Toast.LENGTH_LONG).show();
                }
            }
        });
        return view;
    }
}
