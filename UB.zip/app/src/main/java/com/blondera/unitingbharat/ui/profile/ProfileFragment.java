package com.blondera.unitingbharat.ui.profile;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.blondera.unitingbharat.R;
import com.blondera.unitingbharat.utils.ProjectApi;
import com.blondera.unitingbharat.utils.UserData;

import org.json.JSONArray;

import java.util.HashMap;
import java.util.Map;

public class ProfileFragment extends Fragment {
    EditText edt_fnm,edt_lnm,edt_add,edt_land,edt_dist,edt_st,edt_ref,edt_pin,edt_mob,edt_pan,edt_upi,edt_pass;
    Button btn_update;
    ProgressBar pb;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile,container,false);
        edt_fnm = view.findViewById(R.id.edt_name);
        edt_lnm = view.findViewById(R.id.edt_lname);
        edt_add = view.findViewById(R.id.edt_address);
        edt_land = view.findViewById(R.id.edt_landmark);
        edt_dist = view.findViewById(R.id.edt_dst);
        edt_st = view.findViewById(R.id.edt_st);
        edt_pin = view.findViewById(R.id.edt_pin);
        edt_mob = view.findViewById(R.id.edt_mob);
        edt_pan = view.findViewById(R.id.edt_pan);
        edt_upi = view.findViewById(R.id.edt_upi);
        edt_ref = view.findViewById(R.id.edt_ref);
        edt_pass = view.findViewById(R.id.edt_pass);
        btn_update = view.findViewById(R.id.btn_register);
        pb = view.findViewById(R.id.pb);

        String[] nm = UserData.fnam.split(" ");
        try {
            edt_fnm.setText(nm[0].toUpperCase());
            edt_lnm.setText(nm[1].toUpperCase());
        }catch (Exception e){
            Toast.makeText(getActivity().getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
        }
        edt_add.setText(UserData.add.toUpperCase());
        edt_land.setText(UserData.land.toUpperCase());
        edt_dist.setText(UserData.dist.toUpperCase());
        edt_st.setText(UserData.st.toUpperCase());
        edt_pin.setText(UserData.pin);
        edt_mob.setText(UserData.mob);
        edt_pan.setText(UserData.pan.toUpperCase());
        edt_upi.setText(UserData.upi);
        edt_ref.setText(UserData.ref);
        edt_pass.setText(UserData.pass);

        btn_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RequestQueue que = Volley.newRequestQueue(getActivity().getApplicationContext());
                StringRequest req = new StringRequest(Request.Method.POST, ProjectApi.update    , new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        pb.setVisibility(View.INVISIBLE);
                        try {
                            JSONArray arr = new JSONArray(response);
                            String msg = arr.getJSONObject(0).getString("msg");
                            Toast.makeText(getActivity().getApplicationContext(),msg,Toast.LENGTH_LONG).show();
                            if (msg.equalsIgnoreCase("success")){
                                loadUser();
                                Toast.makeText(getActivity().getApplicationContext(),"Updated Successfully",Toast.LENGTH_LONG).show();
                            }
                        }catch (Exception e){
                            Toast.makeText(getActivity().getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        pb.setVisibility(View.INVISIBLE);
                    }
                }){
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String,String> param = new HashMap<String,String>();
                        //upino="+edtupi.getText().toString()+"&adhar="+edtadhar.getText().toString()+"&name="+edtname.getText().toString()+
                        // "&mobile="+edtmob.getText().toString()+"&ref="+edtref.getText().toString()+"&password="+edtpassword.getText().toString()
                        param.put("uid",UserData.uid);
                        param.put("upino",edt_upi.getText().toString());
                        param.put("name",edt_fnm.getText().toString()+" "+edt_lnm.getText().toString());
                        param.put("mobile",edt_mob.getText().toString());
                        param.put("ref",edt_ref.getText().toString());
                        param.put("ct",edt_dist.getText().toString());
                        param.put("st",edt_st.getText().toString());
                        param.put("land",edt_land.getText().toString());
                        param.put("add",edt_add.getText().toString());
                        param.put("pin",edt_pin.getText().toString());
                        param.put("pan",edt_pan.getText().toString());
                        param.put("password",edt_pass.getText().toString());

                        return param;
                    }
                };
                que.add(req);
            }
        });

        return view;
    }

    private void loadUser() {
        pb.setVisibility(View.VISIBLE);
        RequestQueue que = Volley.newRequestQueue(getActivity().getApplicationContext());
        StringRequest req = new StringRequest(Request.Method.POST, ProjectApi.login, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                pb.setVisibility(View.INVISIBLE);
                try {
                    JSONArray obj = new JSONArray(response);
                    String msg = obj.getJSONObject(0).getString("msg");
                    if (msg.toLowerCase().equalsIgnoreCase("success")) {
                        UserData.uid = obj.getJSONObject(0).getString("uid");
                        UserData.fnam = obj.getJSONObject(0).getString("uname");
                        UserData.add = obj.getJSONObject(0).getString("add");
                        UserData.land = obj.getJSONObject(0).getString("land");
                        UserData.pin = obj.getJSONObject(0).getString("pin");
                        UserData.pan = obj.getJSONObject(0).getString("pan");
                        UserData.mob = obj.getJSONObject(0).getString("mob");
                        UserData.upi = obj.getJSONObject(0).getString("upiid");
                        UserData.ref = obj.getJSONObject(0).getString("ref");
                        UserData.pass = obj.getJSONObject(0).getString("ps");
                        UserData.cnt = obj.getJSONObject(0).getString("cnt");
                        UserData.lvl = obj.getJSONObject(0).getString("level");
                        UserData.pstatus = obj.getJSONObject(0).getString("pstatus");
                        Toast.makeText(getActivity().getApplicationContext(),msg,Toast.LENGTH_LONG).show();

                    }else{
                        Toast.makeText(getActivity().getApplicationContext(),msg,Toast.LENGTH_LONG).show();
                    }
                }catch (Exception e){
                    Toast.makeText(getActivity().getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                pb.setVisibility(View.INVISIBLE);
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<String, String>();
                params.put("umob",UserData.mob);
                params.put("upass",UserData.pass);
                return params;
            }
        };

        que.add(req);
    }
}
