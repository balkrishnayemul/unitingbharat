package com.blondera.unitingbharat.ui.home;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.blondera.unitingbharat.BuildConfig;
import com.blondera.unitingbharat.R;
import com.blondera.unitingbharat.utils.AdData;
import com.blondera.unitingbharat.utils.ProjectApi;
import com.blondera.unitingbharat.utils.UserData;
import com.squareup.picasso.Picasso;

import java.net.URLEncoder;

public class HomeFragment extends Fragment {

    private HomeViewModel homeViewModel;
    TextView txt_nm,txt_ref,txt_lvl,txt_amt,txt_share;
    LinearLayout layout_copy;
    ImageView img_ad;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        homeViewModel =
                ViewModelProviders.of(this).get(HomeViewModel.class);
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        txt_nm = root.findViewById(R.id.txt_nm);
        txt_ref = root.findViewById(R.id.txt_ref);
        txt_lvl = root.findViewById(R.id.txt_lvl);
        txt_amt = root.findViewById(R.id.txt_amt);
        txt_share = root.findViewById(R.id.txt_share);
        img_ad = root.findViewById(R.id.img_ad);

        loadImg();
        layout_copy = root.findViewById(R.id.layout_copy);


        txt_nm.setText("Name : "+ UserData.fnam);
        txt_ref.setText("Referral ID : "+UserData.ref);
        txt_lvl.setText("Level : "+UserData.lvl);
        txt_amt.setText("Income Earned : \u20B9 "+(Integer.parseInt(UserData.cnt)*50));
        /*final TextView textView = root.findViewById(R.id.text_home);
        homeViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });*/
        txt_share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PackageManager packageManager = getActivity().getPackageManager();
                Intent i = new Intent(Intent.ACTION_VIEW);

                try {
                    String message = "Hi, I am inviting you to join UNITING BHARAT product Referral Business\n\nApp Link - https://play.google.com/store/apps/details?id="+ BuildConfig.APPLICATION_ID +"\n\n Referral Link - https://www.unitingbharat.com?ref="+ UserData.ref+"\n\n Website - https://blonderadigitalservicespvtltd.com\n\nReferral Mobile No. - "+UserData.mob;
                    String url = "https://api.whatsapp.com/send?text=" + URLEncoder.encode(message, "UTF-8");
                    i.setPackage("com.whatsapp");
                    i.setData(Uri.parse(url));
                    if (i.resolveActivity(packageManager) != null) {
                        getActivity().startActivity(i);
                    }
                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        });

        layout_copy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ClipboardManager clipboard = (ClipboardManager) getActivity().getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("ub", UserData.ref);
                clipboard.setPrimaryClip(clip);
            }
        });
        return root;
    }

    private void loadImg() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                ProjectApi.i++;
                if (ProjectApi.i>=AdData.adData.size()) {
                    ProjectApi.i=0;
                }
                Picasso.get()
                        .load(ProjectApi.port+"upload/"+ AdData.adData.get(ProjectApi.i).getPath())
                        .into(img_ad);
                loadImg();
            }
        },5000);
    }
}