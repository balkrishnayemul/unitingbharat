package com.blondera.unitingbharat.ui.showTree;

import java.util.ArrayList;

public class TreeData {
    String ref,name,pstatus;

    public String getRef() {
        return ref;
    }

    public void setRef(String ref) {
        this.ref = ref;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPstatus() {
        return pstatus;
    }

    public void setPstatus(String pstatus) {
        this.pstatus = pstatus;
    }

    public static ArrayList<TreeData> treeData = new ArrayList<>();
}
