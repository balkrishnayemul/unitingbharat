package com.blondera.unitingbharat.utils;

public class UserData {
    public static String uid,fnam,add,land,dist,st,pin,mob,pan,upi,ref,pass,pstatus,cnt,lvl;
}
