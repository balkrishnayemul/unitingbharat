package com.blondera.unitingbharat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.blondera.unitingbharat.utils.AdData;
import com.blondera.unitingbharat.utils.ProjectApi;
import com.blondera.unitingbharat.utils.UserData;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {

    ProgressBar pb;
    EditText edt_usr,edt_psw;
    ImageView img_ad;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportActionBar().hide();
        edt_usr = findViewById(R.id.edt_number);
        edt_psw = findViewById(R.id.edt_password);
        pb = findViewById(R.id.pb);
        img_ad = findViewById(R.id.img_ad);
        Picasso.get()
                .load(ProjectApi.port+"upload/"+ AdData.adData.get(ProjectApi.i).getPath())
                .into(img_ad);
        loadImg();
        pb.setVisibility(View.INVISIBLE);
    }

    private void loadImg() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                if (ProjectApi.i>=AdData.adData.size()) {
                    ProjectApi.i=0;
                }
                Picasso.get()
                        .load(ProjectApi.port+"upload/"+ AdData.adData.get(ProjectApi.i).getPath())
                        .into(img_ad);

                loadImg();
            }
        },5000);
    }

    public void login(View view) {
        pb.setVisibility(View.VISIBLE);
        RequestQueue que = Volley.newRequestQueue(getApplicationContext());
        StringRequest req = new StringRequest(Request.Method.POST, ProjectApi.login, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                pb.setVisibility(View.INVISIBLE);
                try {
                    JSONArray obj = new JSONArray(response);
                    String msg = obj.getJSONObject(0).getString("msg");
                    if (msg.toLowerCase().equalsIgnoreCase("success")) {
                        UserData.uid = obj.getJSONObject(0).getString("uid");
                        UserData.fnam = obj.getJSONObject(0).getString("uname");
                        UserData.add = obj.getJSONObject(0).getString("add");
                        UserData.land = obj.getJSONObject(0).getString("land");
                        UserData.pin = obj.getJSONObject(0).getString("pin");
                        UserData.pan = obj.getJSONObject(0).getString("pan");
                        UserData.mob = obj.getJSONObject(0).getString("mob");
                        UserData.upi = obj.getJSONObject(0).getString("upiid");
                        UserData.ref = obj.getJSONObject(0).getString("ref");
                        UserData.pass = obj.getJSONObject(0).getString("ps");
                        UserData.dist = obj.getJSONObject(0).getString("ct");
                        UserData.st = obj.getJSONObject(0).getString("st");
                        UserData.cnt = obj.getJSONObject(0).getString("cnt");
                        UserData.lvl = obj.getJSONObject(0).getString("level");
                        UserData.pstatus = obj.getJSONObject(0).getString("pstatus");
                        Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_LONG).show();
                        if (!UserData.pstatus.equalsIgnoreCase("complete")) {
                            Intent home = new Intent(getApplicationContext(), HomeActivity.class);
                            finish();
                            startActivity(home);
                        }
                        else {
                            Intent home = new Intent(getApplicationContext(), WelcomeActivity.class);
                            finish();
                            startActivity(home);
                        }
                    }else{
                        Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_LONG).show();
                    }
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                pb.setVisibility(View.INVISIBLE);
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<String, String>();
                params.put("umob",edt_usr.getText().toString());
                params.put("upass",edt_psw.getText().toString());
                return params;
            }
        };

        que.add(req);

    }

    public void register(View view) {
        Intent reg = new Intent(getApplicationContext(),RegisterActivity.class);
        startActivity(reg);
    }
}