package com.blondera.unitingbharat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.blondera.unitingbharat.utils.AdData;
import com.blondera.unitingbharat.utils.ProjectApi;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        fetchAd();

    }
    public void fetchAd(){
        RequestQueue que = Volley.newRequestQueue(getApplicationContext());
        JsonArrayRequest req = new JsonArrayRequest(ProjectApi.ad, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                try{
                    String msg = response.getJSONObject(0).getString("msg");
                    if (msg.contains("success")){
                        for (int i=1;i<response.length();i++){
                            JSONObject obj = response.getJSONObject(i);
                            AdData data = new AdData();
                            data.setPath(obj.getString("img"));
                            AdData.adData.add(data);
                        }

                    }

                }catch (Exception e){
                    Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
                }
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent login = new Intent(getApplicationContext(),LoginActivity.class);
                        finish();
                        startActivity(login);
                    }
                },2000);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        que.add(req);
    }
}