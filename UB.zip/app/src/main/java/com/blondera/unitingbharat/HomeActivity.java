package com.blondera.unitingbharat;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.blondera.unitingbharat.utils.ProjectApi;
import com.blondera.unitingbharat.utils.UserData;
import com.squareup.picasso.Picasso;

public class HomeActivity extends AppCompatActivity {

    TextView txt_amt;
    ProgressBar pb;
    ImageView img_combo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        getSupportActionBar().hide();
        txt_amt = findViewById(R.id.txt_rs);
        pb = findViewById(R.id.pb);
        img_combo = findViewById(R.id.img_combo);
        Picasso.get()
                .load(ProjectApi.port+"upload/ic_combo_select.jpg")
                .into(img_combo);
        pb.setVisibility(View.INVISIBLE);
        txt_amt.setText("\u20B91500/-");

    }

    public void pay(View view) {
        pb.setVisibility(View.VISIBLE);
        Long tsLong = System.currentTimeMillis()/1000;
        String transaction_ref_id = tsLong.toString()+"UPI"; // This is your Transaction Ref id - Here we used as a timestamp -
        String upi = "open.2000165343@icici";
        String sOrderId= tsLong +"UPI";// This is your order id - Here we used as a timestamp -

        /*Log.e("TR Reference ID==>",""+transaction_ref_id);*/
        Uri myAction = Uri.parse("upi://pay?pa="+upi+"&pn=bankopen&mc=&tid="+transaction_ref_id +"&tr="+transaction_ref_id +"&tn=Pay%20to%20Merchant%20Finance%20Assets&am="+"1500.00"+"&mam=null&cu=INR&url=https://mystar.com/orderid="+sOrderId);


        PackageManager packageManager = getPackageManager();
        //Intent intent = packageManager.getLaunchIntentForPackage("com.mgs.induspsp"); // Comment line - if you want to open specific application then you can pass that package name For example if you want to open Bhim app then pass Bhim app package name -
        Intent intent = new Intent();

        if (intent != null) {
            intent.setAction(Intent.ACTION_VIEW);
            intent.setData(myAction);
            // startActivity(intent);
            Intent chooser = Intent.createChooser(intent, "Pay with...");
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                startActivityForResult(chooser, 1, null);
                //sendMoney();

            }

        }
        /*Intent welcomeIntent = new Intent(getApplicationContext(),WelcomeActivity.class);
        finish();
        startActivity(welcomeIntent);*/
    }
    private void sendMoney() {
        try {
            RequestQueue que = Volley.newRequestQueue(getApplicationContext());
            String url = "https://www.unitingbharat.com/payout.php?ref="+ UserData.ref;

            StringRequest req = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    if (response.contains("success")) {
                        pb.setVisibility(View.INVISIBLE);
                        //Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();
                        Intent welcomeIntent = new Intent(getApplicationContext(),WelcomeActivity.class);
                        finish();
                        startActivity(welcomeIntent);

                    }
                    //if (response.toLowerCase().contains("success")){
                        /*if (i<userDataArrayList.size()) {
                            i++;
                            sendMoney();
                        }
                        else if(i>=userDataArrayList.size()){
                            Toast.makeText(getApplicationContext(),"Success",Toast.LENGTH_LONG).show();
                        }*/
                    //Toast.makeText(getApplicationContext(),response,Toast.LENGTH_LONG).show();
                    //}
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                }
            });
            req.setRetryPolicy(new DefaultRetryPolicy(
                    0,
                    DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            que.add(req);

        }catch (Exception e){
            Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    private void updateStatus() {
        try {
            RequestQueue que = Volley.newRequestQueue(getApplicationContext());
            String url = "https://www.unitingbharat.com/PHPDemo/paymentupdate.php?uid="+ UserData.uid;

            StringRequest req = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    if (response.contains("success")) {
                        sendMoney();

                    }
                    
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                }
            });
            req.setRetryPolicy(new DefaultRetryPolicy(
                    0,
                    DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            que.add(req);

        }catch (Exception e){
            Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        pb.setVisibility(View.INVISIBLE);
        if (data != null) {
            if (requestCode == 1) {
                String res = data.getStringExtra("response");
                String search = "SUCCESS";
                if (res.toLowerCase().contains(search.toLowerCase())) {
                    updateStatus();

                    Toast.makeText(this, "Payment Successful", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Payment Failed", Toast.LENGTH_SHORT).show();
                }
            }
        }
        else {
            Toast.makeText(this, "Payment Failed", Toast.LENGTH_SHORT).show();
        }
    }
}