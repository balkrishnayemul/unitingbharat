package com.blondera.unitingbharat.ui.showTree;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.blondera.unitingbharat.R;
import com.blondera.unitingbharat.utils.ProjectApi;
import com.blondera.unitingbharat.utils.UserData;

import org.json.JSONArray;
import org.json.JSONObject;

public class ShowTreeFragment extends Fragment {

    ListView lst_tree;
    TextView txt_cnt;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_show_tree,container,false);
        lst_tree = view.findViewById(R.id.lst_tree);
        txt_cnt = view.findViewById(R.id.txt_cnt);
        fetchTree(UserData.ref);


        lst_tree.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                fetchTree(TreeData.treeData.get(i).getRef());
            }
        });
        return view;
    }

    private void fetchTree(String ref) {
        RequestQueue que = Volley.newRequestQueue(getActivity().getApplicationContext());
        JsonArrayRequest req = new JsonArrayRequest(ProjectApi.tree + ref, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                TreeData.treeData.clear();

                for (int i=0;i<response.length();i++){
                    try {
                        JSONObject obj = response.getJSONObject(i);
                        TreeData treeData = new TreeData();
                        treeData.setRef(obj.getString("ref"));
                        treeData.setName(obj.getString("nm"));
                        treeData.setPstatus(obj.getString("ref"));
                        TreeData.treeData.add(treeData);
                        ShowTreeAdapter adapter = new ShowTreeAdapter(getActivity().getApplicationContext());
                        lst_tree.setAdapter(adapter);
                    }catch (Exception e){
                        Toast.makeText(getActivity().getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
                    }
                }
                txt_cnt.setText("Referral Count : "+response.length()+"    Referral Code : "+UserData.ref);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        que.add(req);
    }
}
