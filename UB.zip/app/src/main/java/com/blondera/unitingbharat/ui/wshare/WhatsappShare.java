package com.blondera.unitingbharat.ui.wshare;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.blondera.unitingbharat.BuildConfig;
import com.blondera.unitingbharat.R;
import com.blondera.unitingbharat.utils.UserData;

import java.net.URLEncoder;

public class WhatsappShare extends Fragment {
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_share,container,false);
        Button btn = view.findViewById(R.id.btn_share);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PackageManager packageManager = getActivity().getPackageManager();
                Intent i = new Intent(Intent.ACTION_VIEW);

                try {
                    String message = "Hi, I am inviting you to join UNITING BHARAT product Referral Business\n\nApp Link - https://play.google.com/store/apps/details?id="+ BuildConfig.APPLICATION_ID +"\n\n Referral Link - https://www.unitingbharat.com?ref="+ UserData.ref+"\n\n Website - https:\\blonderadigitalservicespvtltd.com\n\nReferral Mobile No. - "+UserData.mob;
                    String url = "https://api.whatsapp.com/send?text=" + URLEncoder.encode(message, "UTF-8");
                    i.setPackage("com.whatsapp");
                    i.setData(Uri.parse(url));
                    if (i.resolveActivity(packageManager) != null) {
                        getActivity().startActivity(i);
                    }
                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
        return view;
    }
}
