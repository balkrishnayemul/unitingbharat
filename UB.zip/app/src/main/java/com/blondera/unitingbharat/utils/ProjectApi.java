package com.blondera.unitingbharat.utils;

public class ProjectApi {

    public  static String port="https://www.unitingbharat.com/PHPDemo/";
    public static String login = port+"loginapi_under.php";
    public static String register = port+"mlm_register.php";
    public static String tree = port+"fetchtree.php?ref=";
    public static String update = port+"update_reg.php";
    public static String ad = port+"FetchAd.php";
    public static int i=0;
}
